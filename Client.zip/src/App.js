import Import from "./components/Import";

function App() {
  return (
    <h1>
      <Import />
    </h1>
  );
}

export default App;
